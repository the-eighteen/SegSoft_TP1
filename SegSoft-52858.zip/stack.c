#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//static int i = 0;

void cpy(char *d, char *s, int n)
{
  while (n--!=0) *d++=*s++;
}

void foo(char *str, int s)
{
    char buffer[32];
    buffer[0]=(char)255;
    buffer[1]=(char)255;
   	buffer[2]=(char)255;
   	buffer[3]=(char)255;
   	buffer[4]=(char)255;
   	buffer[5]=(char)255;
   buffer[6]=(char)255;
   buffer[7]=(char)255;
   buffer[8]=(char)255;
   buffer[9]=(char)255;
   buffer[10]=(char)255;
   buffer[11]=(char)255;
   buffer[12]=(char)255;
   buffer[13]=(char)255;
   buffer[14]=(char)255;
   buffer[15]=(char)255;
   buffer[16]=(char)255;
   buffer[17]=(char)255;
   buffer[18]=(char)255;
   buffer[19]=(char)255;
   buffer[20]=(char)255;
   buffer[21]=(char)255;
   buffer[22]=(char)255;
   buffer[23]=(char)255;
   buffer[24]=(char)255;
   buffer[25]=(char)255;
   buffer[26]=(char)255;
   buffer[27]=(char)255;
   buffer[28]=(char)255;
   buffer[29]=(char)255;
   buffer[30]=(char)255;
   buffer[31]=(char)255;
   
   
   
    printf("buffer AT %lx\n",(long)&buffer);
      printf("%lx\n", ((long*)buffer)[0]);
      printf("%lx\n", ((long*)buffer)[1]);
      printf("%lx\n", ((long*)buffer)[2]);
      printf("%lx\n", ((long*)buffer)[3]);
      printf("%lx\n", ((long*)buffer)[4]);
      printf("%lx\n", ((long*)buffer)[5]);
      printf("%lx\n", ((long*)buffer)[6]);
      printf("%lx\n", ((long*)buffer)[7]);
   
    cpy(buffer, str, s); /* buffer overflow here */
    
}

int main(int argc, char **argv)
{
    char str[400];
    FILE *badfile;
    int retval = 0;

    badfile = fopen("smasher", "r");
    int s = fread(str, sizeof(char), 400, badfile);
    foo(str,s);
    retval = 0;  // write a virus that changes the retval to 66
    
    return retval;
}

/* utils to inspect frame of foo */
   

    /*
    for(int i = 0; i<8; i++)
      printf("%d : %lx\n", i, ((long*)buffer)[i]);
    */
